# 💸 Boutique Vallya

## 🛒 Boutique Vallya

### Comment récupérer les objets achetés en boutique ?

Si vous avez effectué un achat en boutique avec des euros, voici les étapes à suivre pour récupérer vos objets en jeu.

#### 1️⃣ Accéder au **Menu Vallya**

* Vous devez **cliquer sur le canon** présent dans l'interface du jeu pour ouvrir le **Menu Vallya**.
*

    <figure><img src=".gitbook/assets/image (42).png" alt=""><figcaption></figcaption></figure>

#### 2️⃣ Accéder à la section **Rang Vallya**

* Une fois le **Menu Vallya** ouvert, vous devez **cliquer sur l'option "Rang Vallya"**.
*

    <figure><img src=".gitbook/assets/image (43).png" alt=""><figcaption></figcaption></figure>

#### 3️⃣ Finaliser l'achat et activer vos avantages

* Dans cette nouvelle fenêtre, vous trouverez les **différentes offres disponibles**.
* Cliquez sur **"Devenir Avantagé !"** ou **"Devenir Premium !"** en fonction de votre achat.
*

    <figure><img src=".gitbook/assets/image (44).png" alt=""><figcaption></figcaption></figure>

#### 💰 **Avantages des Offres**

<table><thead><tr><th width="162">💎 Offre</th><th width="150">💰 Prix</th><th>🎁 Bonus</th></tr></thead><tbody><tr><td><strong>Avantagé</strong></td><td><strong>35€</strong></td><td>1250 Ogrines, Boost XP +100%, Prog Item x1.75, Boost Parchemins x1.50, Daily x2, +5 Sorts PR Omega</td></tr><tr><td><strong>Premium</strong></td><td><strong>15€</strong></td><td>750 Ogrines, Boost XP +50%, Drop +30%, Prog Normal, Parchemins Normaux</td></tr></tbody></table>

Après validation de votre achat, les avantages seront **directement activés** sur votre compte en jeu. Profitez pleinement de votre expérience sur **Vallya** ! 🎉🔥
