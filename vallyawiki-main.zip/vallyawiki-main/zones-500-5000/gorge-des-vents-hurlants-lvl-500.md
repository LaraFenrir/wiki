# 🍂 Gorge des Vents Hurlants (LvL 500)

## 🌱 Zone Niveau 500 – Gorge des Vents Hurlants

Le **Gorge des Vents Hurlants** est une zone destinée aux aventuriers ayant atteint le niveau 1000. Vous y trouverez des équipements spéciaux et un donjon offrant des récompenses exclusives.

### 🏆 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l’ensemble complet du Stuff de Prestance**, vous aurez besoin d'un total de **770 ressources de la zone**, en prenant en compte **2 anneaux**.

<figure><img src="../.gitbook/assets/image (16).png" alt=""><figcaption></figcaption></figure>

***

### 🔮 **L’artefact du Père Ver**

En échangeant certaines **ressources obtenues dans le donjon**, vous pourrez récupérer **l’artefact du Père Ver**. Cet objet peut être utile pour progresser davantage dans votre aventure.

<figure><img src="../.gitbook/assets/image-1 (11).png" alt=""><figcaption></figcaption></figure>

***

### 🏠 **Le donjon : Boyau du Père Ver**

Le **Boyau du Père Ver** est un donjon redoutable où vous pourrez affronter des créatures puissantes. C’est également **le seul endroit où vous pourrez obtenir le Dofus Verdoyant**.

#### 🎁 **Récompense rare :**

* **Dofus Verdoyant**
  * 📍 _Instance_ : Boyau du Père Ver
  * 🎯 _Taux de drop_ : **0,04%**

<figure><img src="../.gitbook/assets/image.png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous à affronter des défis de taille et à collecter les meilleures récompenses ! 🔥⚔️
