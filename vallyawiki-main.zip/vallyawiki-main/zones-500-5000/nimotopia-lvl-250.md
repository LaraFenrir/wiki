# 🌿 Nimotopia (LvL 250)

## 🌿 Zone Niveau 250– Nimotopia

La **zone de Nimotopia** est accessible des le début. Elle regorge de créatures spécifiques et propose un équipement adapté aux joueurs de ce palier.

<figure><img src="../.gitbook/assets/image (28).png" alt=""><figcaption></figcaption></figure>

### 🏆 **Ressources nécessaires pour l'équipement complet**

Dans le **Magasin de Nimotopia**, vous trouverez plusieurs équipements qui nécessitent des **ressources de la zone**. Pour obtenir l’ensemble complet, vous devrez accumuler **280 ressources de Nimotopia**, en prenant en compte l’achat de **deux anneaux**.

<figure><img src="../.gitbook/assets/image-1 (8).png" alt=""><figcaption></figcaption></figure>

***

### 🦴 **Échange de ressources contre un familier**

Un **PNJ d’échange** situé dans la zone permet aux joueurs de convertir **certaines ressources de Nimotopia** en un **familier exclusif**.

<figure><img src="../.gitbook/assets/image (29).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (34).png" alt=""><figcaption></figcaption></figure>

***

### 🏰 **Accès au Donjon : Camp du Comte Razof**

Le **donjon de Nimotopia**, aussi connu sous le nom de **Camp du Comte Razof**, est une instance où vous pourrez affronter des ennemis plus puissants et obtenir des récompenses spéciales.

<figure><img src="../.gitbook/assets/image-1 (9).png" alt=""><figcaption></figcaption></figure>

***

### 🏅 **Récompenses du Donjon**

Dans ce donjon, vous aurez la possibilité de récupérer **des objets rares et des équipements puissants**. Deux objets sont particulièrement prisés :

* **Dofus du Débutant** 🐉
* **Bouclier du Mont Kipou Brisé** 🛡️

<figure><img src="../.gitbook/assets/image (30).png" alt=""><figcaption></figcaption></figure>

***

### 🏆 **Obtenir la Relique du Donjon**

Pour récupérer la **Relique du Député**, nécessaire pour certaines améliorations ou quêtes, il faudra **rassembler des ressources spécifiques** et les échanger auprès du PNJ dédié.

<figure><img src="../.gitbook/assets/image-1 (10).png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous pour des combats intenses et des récompenses exceptionnelles dans **Nimotopia** ! ⚔️🔥
