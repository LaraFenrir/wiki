# 👹 Crépuscule Brâkmarien (LvL 1000)

## 🌑 Zone Niveau 1000 – Crépuscule Brâkmarien

Le **Crépuscule Brâkmarien** est une zone destinée aux aventuriers de niveau 1000. Cette zone vous permettra d'obtenir des équipements puissants, un familier exclusif et un objet rare via son donjon.

### 🏆 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l'ensemble complet du Stuff du Diplomate**, vous aurez besoin d'un total de **525 ressources de la zone**, en prenant en compte **2 anneaux**.

<figure><img src="../.gitbook/assets/image (15).png" alt=""><figcaption></figcaption></figure>

***

### 🦊 **Obtenir un familier**

En échangeant certaines **ressources spécifiques obtenues dans la zone**, vous pourrez récupérer **un familier exclusif**.

<figure><img src="../.gitbook/assets/image-1 (7).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (35).png" alt=""><figcaption></figcaption></figure>

***

### 🏠 **Le donjon : Repère Brâkmarien**

Le **Repère Brâkmarien** est un donjon redoutable qui renferme une surprise de taille : **le Dofus Visqueux**.

#### 🎁 **Récompense rare :**

* **Dofus Visqueux**
  * 📍 _Instance_ : Repère Brâkmarien
  * 🎯 _Taux de drop_ : **0,03%**

<figure><img src="../.gitbook/assets/image (1).png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous à affronter des défis de taille et à collecter les meilleures récompenses ! 🔥⚔️
