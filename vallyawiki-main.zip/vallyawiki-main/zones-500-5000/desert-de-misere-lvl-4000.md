# 🏜️ Désert de Misère (LvL 4000)

## 🌫️ Désert de Misère (LvL 4000)

Le **Désert de Misère** est une zone destinée aux aventuriers de niveau **4000**. Dans cette zone, vous pourrez obtenir un ensemble d'équipements spécifiques ainsi qu'un familier exclusif en échange des ressources de la zone.

***

### 💪 **Ressources nécessaires pour l'équipement complet**

Pour obtenir l'équipement **Doré** en entier, il faudra collecter un total de **4900 ressources** de la zone, en comptant **deux anneaux**.

<figure><img src="../.gitbook/assets/image (9).png" alt=""><figcaption></figcaption></figure>

***

### 🌟 **Obtention du Familier**

En échangeant certaines ressources spécifiques obtenues en battant les créatures du **Désert de Misère**, vous pourrez obtenir un familier unique.

<figure><img src="../.gitbook/assets/image-1 (1).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (11).png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous à affronter les dangers du **Désert de Misère** et à collecter ces récompenses rares ! 💥🛡️
