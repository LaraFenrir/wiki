# 🏫 Royaume Corrompu (LvL 2500)

## 🏰 Royaume Corrompu (LvL 2500)

Le **Royaume Corrompu** est une zone de niveau **2500**, où les aventuriers pourront obtenir des équipements puissants, récupérer une arme spéciale et tenter leur chance pour obtenir un **Dofus Temporelle** dans le donjon de la zone.

***

### 🛡️ **Équipements du Royaume Corrompu**

Dans cette zone, vous pouvez acheter l'équipement **Temporelle** en échange de **1 500 ressources de la zone**.

#### 🛒 Boutique des équipements :

<figure><img src="../.gitbook/assets/image (14).png" alt=""><figcaption></figcaption></figure>

**Ressources totales nécessaires pour un équipement complet :**

* **9 000 ressources** si vous achetez toutes les pièces.
* **10 500 ressources** en comptant **deux anneaux**.

***

### ⚔️ **Obtention de la Dague Corrompue**

Il est possible d’échanger des **ressources spécifiques obtenues dans la zone** contre la **Dague Corrompue**.

#### 🔄 Échange des ressources contre la dague :

<figure><img src="../.gitbook/assets/image (31).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (38).png" alt=""><figcaption></figcaption></figure>

***

### ⏳ **Dofus Temporelle**

Le **Dofus Temporelle** est une récompense extrêmement rare que l’on peut obtenir en terminant le **donjon Cercle de Pierre Corrompu**.

🎁 **Récompense rare :**

* **⏳ Dofus Temporelle**
  * 📍 _Instance_ : Cercle de Pierre Corrompu
  * 🎯 _Taux de drop_ : **0,020%**

<figure><img src="../.gitbook/assets/image (5).png" alt=""><figcaption></figcaption></figure>

Préparez-vous à affronter des ennemis redoutables et à récolter des récompenses exceptionnelles ! 🔥⚔️
