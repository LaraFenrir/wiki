# ⚰️ Cimetière de Grobe (LvL 2000)

## ⚰️ Zone Niveau 2000 – Cimetière de Grobe

Le **Cimetière de Grobe** est une zone lugubre réservée aux aventuriers de niveau 2000 et plus. Cette région regorge de défis et offre des équipements redoutables ainsi qu'un familier exclusif.

### 🌟 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l'ensemble complet du Stuff du Brave**, vous devrez collecter **910 ressources de la zone**, en prenant en compte **2 alliances**.

<figure><img src="../.gitbook/assets/image (13).png" alt=""><figcaption></figcaption></figure>

***

### 🐺 **Le familier exclusif**

Vous pourrez échanger certaines **ressources obtenues dans la zone** pour obtenir **un familier unique**.

<figure><img src="../.gitbook/assets/image-1 (5).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (37).png" alt=""><figcaption></figcaption></figure>

***

### 💀 **Le donjon : Temple Hanté d'Ougah**

Dans cette zone hantée, vous aurez l'opportunité d'affronter les esprits tourmentés du **Temple Hanté d'Ougah**. C’est également ici que vous pourrez obtenir le **Fantofus**.

#### 🎁 **Récompense rare :**

* **Fantofus**
  * 📍 _Instance_ : Temple Hanté d'Ougah
  * 🎯 _Taux de drop_ : **0,025%**

<figure><img src="../.gitbook/assets/image (3).png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous à explorer ce lieu mystique et à en ressortir plus puissant que jamais ! 🔮👻
