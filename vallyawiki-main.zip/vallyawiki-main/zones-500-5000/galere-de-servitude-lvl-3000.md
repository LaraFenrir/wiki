# ⚓ Galère de Servitude (LvL 3000)

## ⚓ Galère de Servitude (Niveau 3000)

La **Galère de Servitude** est une zone conçue pour les aventuriers ayant atteint le **niveau 3000**. Cette région abrite de puissants ennemis et permet d'acquérir un équipement spécifique ainsi qu'un familier rare.

### 🏆 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l’ensemble complet du Stuff du Serviable**, vous aurez besoin d'un total de **560 ressources de la zone**, en prenant en compte **2 anneaux**.

#### 🛒 Boutique d’équipements

📍 _Emplacement_ : Magasin de la zone

<figure><img src="../.gitbook/assets/image (32).png" alt=""><figcaption></figcaption></figure>

***

### 🐾 **Le familier de la zone**

En échangeant certaines **ressources obtenues dans la zone**, vous pourrez récupérer **un familier exclusif**.

#### 📜 Procédure d'échange

📍 _PNJ Otomaï_ 📦 _Ressources requises_ : À récupérer sur les créatures de la zone

<figure><img src="../.gitbook/assets/image-1 (12).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (39).png" alt=""><figcaption></figcaption></figure>

***

### ⚔ **Défi de la Servitude – Le Donjon de la zone**

Le **Défi de la Servitude** est l’épreuve ultime de la Galère de Servitude. Vous devrez affronter des créatures redoutables et relever un défi stratégique pour en sortir vainqueur.

#### 🎁 **Récompense rare :**

* **🔥 Plasta**
  * 📍 _Instance_ : Défi de la Servitude
  * 🎯 _Taux de drop_ : **0,50%**
  * **évolutif dans la zone de drop**

<figure><img src="../.gitbook/assets/image (6).png" alt=""><figcaption></figcaption></figure>

Préparez-vous à affronter des ennemis redoutables et à prouver votre puissance ! 💪🔥
