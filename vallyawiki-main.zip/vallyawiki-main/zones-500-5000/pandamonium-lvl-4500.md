# 🐼 Pandamonium (LvL 4500)

## 🐼 Pandamonium (LvL 4500)

Le **Pandamonium** est une zone redoutable pour les aventuriers ayant atteint le niveau **4500**. Vous pourrez y récupérer un équipement puissant, échanger des ressources contre une arme exceptionnelle et préparer votre progression vers le donjon de **Kanigroula**.

### 🏆 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l’ensemble complet du Stuff Ravagé**, vous aurez besoin d'un total de **3500 ressources de la zone**, en prenant en compte **2 bagues**.

<figure><img src="../.gitbook/assets/image (7).png" alt=""><figcaption></figcaption></figure>

***

### 🔨 **Obtention du Marteau Réfacteur**

Dans cette zone, il est possible d'échanger certaines **ressources spécifiques** contre le **Marteau Réfacteur**, une arme puissante offrant des statistiques considérables.

<figure><img src="../.gitbook/assets/image-1.png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (8).png" alt=""><figcaption></figcaption></figure>

***

### ✨ **Dofus Béni**

Le **Dofus Béni** peut être obtenu exclusivement dans le **donjon de Kanigroula**, accessible **à partir du niveau 5000**.

#### 🎁 **Récompense rare :**

* **Dofus Béni**
  * 📍 _Instance_ : Grotte de Kanigroula
  * 🎯 _Taux de drop_ : **0,080%**

<figure><img src="../.gitbook/assets/image (41).png" alt=""><figcaption></figcaption></figure>

***

Préparez-vous pour l’un des défis les plus redoutables et armez-vous des meilleurs équipements pour progresser ! 🔥⚔️
