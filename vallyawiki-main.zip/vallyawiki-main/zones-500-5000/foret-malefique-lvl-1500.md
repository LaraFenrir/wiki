# 🌲 Forêt Maléfique (LvL 1500)

## 🌲 Zone Niveau 1500 – Forêt Maléfique

La **Forêt Maléfique** est une zone hostile pour les aventuriers ayant atteint le niveau 1500. Vous y trouverez des équipements uniques et pourrez obtenir un **objet rare** en échangeant des ressources.

### 🏆 **Ressources nécessaires pour l'équipement complet**

Pour obtenir **l’ensemble complet du Stuff Feuillu**, vous aurez besoin d'un total de **875 ressources de la zone**, en prenant en compte **2 alliances**.

<figure><img src="../.gitbook/assets/image (12).png" alt=""><figcaption></figcaption></figure>

***

### 🌱 **Obtention du Cac Racine de Floribonde**

En échangeant certaines **ressources obtenues dans la zone**, vous pourrez obtenir **le Cac Racine de Floribonde**, une arme rare qui vous aidera dans vos combats.

<figure><img src="../.gitbook/assets/image-1 (3).png" alt=""><figcaption></figcaption></figure>

<figure><img src="../.gitbook/assets/image (36).png" alt=""><figcaption></figcaption></figure>

***

### 🏠 **Le donjon : Entraille de la Forêt Sombre**

L’**Entraille de la Forêt Sombre** est un donjon redoutable dans lequel vous pourrez tester vos capacités face à des créatures féroces. C’est aussi **le seul endroit où vous pourrez obtenir l’Arbraskofus**.

#### 🎁 **Récompense rare :**

* **Arbraskofus**
  * 📍 _Instance_ : Entraille de la Forêt Sombre
  * 🎯 _Taux de drop_ : **0,03%**

<figure><img src="../.gitbook/assets/image (2).png" alt=""><figcaption></figcaption></figure>

***

Affrontez les dangers de la forêt, amassez des ressources et obtenez des récompenses exclusives ! 🌿⚔️
