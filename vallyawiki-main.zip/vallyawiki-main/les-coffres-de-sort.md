# 🎮 Les Coffres de Sort

🔑 Les **coffres de sort** sont des objets spéciaux que vous pouvez obtenir en affrontant des monstres à travers le monde des Douze. Ces coffres contiennent des **parchemins de sort**, qui vous permettent d'apprendre ou d'améliorer vos compétences magiques.

***

### 🎁 Les différents types de coffres

<table data-card-size="large" data-view="cards"><thead><tr><th>Coffre</th><th>Apparence</th><th>Rareté</th><th>Récompense</th><th data-hidden data-card-cover data-type="files"></th></tr></thead><tbody><tr><td>🏅 <strong>Coffre de Sort [Commun]</strong></td><td>📦 Gris</td><td>Commun</td><td>Sort commun</td><td><a href=".gitbook/assets/commun.png">commun.png</a></td></tr><tr><td>🔷 <strong>Coffre de Sort [Rare]</strong></td><td>📦 Bleu</td><td>Rare</td><td>Sort rare</td><td><a href=".gitbook/assets/rare.png">rare.png</a></td></tr><tr><td>🟣 <strong>Coffre de Sort [Épique]</strong></td><td>📦 Violet</td><td>Épique</td><td>Sort épique</td><td><a href=".gitbook/assets/epique.png">epique.png</a></td></tr><tr><td>🟡 <strong>Coffre de Sort [Légendaire]</strong></td><td>📦 Doré</td><td>Légendaire</td><td>Sort légendaire</td><td><a href=".gitbook/assets/leg.png">leg.png</a></td></tr></tbody></table>

***

### 🔄 **Échange et amélioration des coffres**

Vous pouvez **améliorer vos coffres** en les échangeant contre des versions plus rares :

* **25 Coffres Commun** → **1 Coffre Rare**
* **50 Coffres Rare** → **1 Coffre Épique**
* **100 Coffres Épique** → **1 Coffre Légendaire**

Cela vous permet de transformer des coffres basiques en coffres plus puissants, augmentant ainsi la valeur des parchemins obtenus.

<figure><img src=".gitbook/assets/image (18).png" alt=""><figcaption><p>Zone (Pnj's Utile)</p></figcaption></figure>

***

### 🗺️ Où trouver ces coffres ?

🎯 Ces coffres peuvent être obtenus en **drop sur tous les monstres** du monde des Douze.

***

### 🔥 **Utilisation des coffres et des parchemins**

1️⃣ **Ouvrir le coffre** 🎁 → Obtenez un **parchemin de sort**. 2️⃣ **Double-cliquez sur le parchemin** 📜 → Débloquez un **sort**. 3️⃣ **Gérez vos sorts** 🔄 → Vous pouvez **convertir un sort** en **parchemin échangeable** si vous souhaitez le réutiliser ou l’échanger.

<figure><img src=".gitbook/assets/image (19).png" alt=""><figcaption></figcaption></figure>

⚠️ **Limite des sorts** : Un joueur peut posséder jusqu’à **25 sorts actifs**.

***

➡️ **"Vous trouverez la liste complète des sorts contenus dans chaque coffre dans la section "Contenu des Coffres de Sort"**

{% content-ref url="contenu-des-coffres-de-sort.md" %}
[contenu-des-coffres-de-sort.md](contenu-des-coffres-de-sort.md)
{% endcontent-ref %}

