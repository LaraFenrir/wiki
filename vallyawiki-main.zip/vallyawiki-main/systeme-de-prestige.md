# 🏆 Système de Prestige

## 🌟 Qu'est-ce que le Prestige ?

Le **Prestige** est une fonctionnalité avancée qui permet aux joueurs d’augmenter leur puissance après avoir atteint le niveau maximum. En échange d’une **remise à zéro de votre niveau uniquement** (vous conservez vos équipements et ressources), vous débloquez des **bonus exclusifs permanents**, rendant votre personnage plus fort à chaque Prestige.

C’est un système destiné aux joueurs les plus ambitieux qui souhaitent repousser leurs limites et obtenir des **améliorations uniques**.

***

### **Passer le Prestige**

* Si vous remplissez les conditions, appuyez sur **"Passer le Prestige"**.
* **Votre niveau sera réinitialisé à 200**, mais vous recevrez les **bonus permanents** associés.

📌 _Référez-vous à l’image ci-dessous pour voir les étapes détaillées :_

<figure><img src=".gitbook/assets/prestige.png" alt=""><figcaption></figcaption></figure>

***

### 📊 Récompenses par niveau de Prestige

<table><thead><tr><th width="140">Prestige</th><th>Bonus</th></tr></thead><tbody><tr><td><strong>1</strong></td><td><strong>+25,000 Sagesse</strong> 🧠✨</td></tr><tr><td><strong>2</strong></td><td><strong>+650,000 Puissance</strong> ⚡</td></tr><tr><td><strong>3</strong></td><td><strong>+1,000,000 Vitalité</strong> 🔥</td></tr><tr><td><strong>4</strong></td><td><strong>+250,000 Chance</strong> 💧, <strong>+250,000 Intelligence</strong> 🔥, <strong>+250,000 Agilité</strong> 🍃, <strong>+250,000 Force</strong> 💪</td></tr><tr><td><strong>5</strong></td><td><strong>+35,000 Sagesse</strong> 🧠✨</td></tr><tr><td><strong>6</strong></td><td><strong>+1,500,000 Vitalité</strong> 🔥</td></tr><tr><td><strong>7</strong></td><td><strong>+500,000 Chance</strong> 💧, <strong>+500,000 Intelligence</strong> 🔥, <strong>+500,000 Agilité</strong> 🍃, <strong>+500,000 Force</strong> 💪</td></tr><tr><td><strong>8</strong></td><td><strong>+280,000 Chance</strong> 💧, <strong>+280,000 Intelligence</strong> 🔥, <strong>+280,000 Agilité</strong> 🍃, <strong>+280,000 Force</strong> 💪</td></tr><tr><td><strong>9</strong></td><td><strong>+5,000 Dégâts Critiques</strong> 💥</td></tr><tr><td><strong>10</strong></td><td><strong>+750,000 Puissance des Dégâts</strong> ⚡, <strong>+5,000 Bonus aux Dégâts</strong> 🔥, <strong>+5,000 Dégâts Critiques</strong> 💥</td></tr></tbody></table>

#### 🔥 **Les Prestiges 10 à 30** continuent avec des **bonus répétés** :

* **+750,000 Puissance des Dégâts** ⚡
* **+5,000 Bonus aux Dégâts** 🔥
* **+5,000 Dégâts Critiques** 💥

***

### ⚠️ Notes Importantes

* Chaque Prestige **ajoute ses bonus en plus des précédents** (effet cumulatif).
* **Vous recommencez au niveau 200** après chaque Prestige.
* Les **Prestiges 10 à 30** offrent des récompenses répétées.

***

Avec ce système, le Prestige permet d’accéder à des **bonus puissants et exclusifs**, rendant chaque passage plus intéressant ! 🎉
