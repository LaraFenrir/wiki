# 🔮 Runes

## 🔮 Runes

Les **runes** permet aux joueurs d’obtenir des bonus uniques en échangeant des ressources spécifiques auprès d’un PNJ dédié.

***

### 📍 **Comment y accéder ?**

🔹 **Localisation** : Le PNJ d’échange de runes se trouve à **Saharach (Port de Sarakech)** en **(15,-56)**. 🔹 **Accès rapide** : Vous pouvez utiliser le **téléporteur** pour vous rendre directement au PNJ.

<figure><img src=".gitbook/assets/image (24).png" alt=""><figcaption></figcaption></figure>

<figure><img src=".gitbook/assets/image (25).png" alt=""><figcaption></figcaption></figure>

***

### 🔄 **Échange des runes**

💠 **PNJ : Simgood le marin** vous permet d’échanger vos ressources contre des runes. 💠 Chaque transaction vous permet d’obtenir des runes spéciales pour améliorer votre équipement.

<figure><img src=".gitbook/assets/image (26).png" alt=""><figcaption></figcaption></figure>

***

🔥 **Profitez de ce système pour renforcer votre personnage et optimiser votre équipement !**
