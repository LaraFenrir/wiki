# ⚔️ Daily Fight

Le **Daily Fight** est un défi quotidien permettant aux joueurs d'affronter un adversaire redoutable pour gagner des récompenses exclusives. Ce combat ne peut être réalisé **qu'une seule fois toutes les 24 heures**.

### ⚔️ **Comment y accéder ?**

🔹 Pour participer au **Daily Fight**, vous devez vous rendre auprès du PNJ dédié.\
🔹 Un **système de téléportation** est disponible pour faciliter l’accès.

<figure><img src=".gitbook/assets/image (22).png" alt=""><figcaption></figcaption></figure>

***

### 💀 **Le combat contre le Dopeul**

* Le **Dopeul** que vous affrontez possède un pourcentage de **vos propres statistiques**, rendant chaque combat unique.
* Vous devez le **vaincre pour obtenir des récompenses**.
* **Fréquence** : 1 combat toutes les **24 heures** (soit **1 fois par jour**).

***

### 🎟️ **Récompenses et boutique**

* À chaque victoire, vous obtenez **2 tickets**.
* Ces tickets peuvent être échangés dans un **magasin spécial** pour obtenir des objets exclusifs.

<figure><img src=".gitbook/assets/image (23).png" alt=""><figcaption></figcaption></figure>

***

🔥 **Ne manquez pas votre combat quotidien et accumulez des tickets pour obtenir des récompenses incroyables !**
