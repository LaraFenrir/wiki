# 🎁 Bonus Journalier

Chaque jour, profitez de **bonus uniques** pour booster votre progression dans le jeu !

| 📅 Jour      | 🎉 Bonus Actif            |
| ------------ | ------------------------- |
| **Lundi**    | Double Avancement (Items) |
| **Mardi**    | Double Kamassus           |
| **Mercredi** | Double Kamas              |
| **Jeudi**    | Double Parcho             |
| **Vendredi** | Double Hardcoria          |
| **Samedi**   | Double Récolte Métier     |
| **Dimanche** | +50% XP                   |

💡 **Astuce** : Planifiez votre semaine pour tirer le meilleur parti de ces bonus et optimiser votre progression ! 🚀🔥
